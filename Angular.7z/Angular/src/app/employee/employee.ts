export interface IEmployee
{
    eid : number;
    ename : string;
    esal : number;
}